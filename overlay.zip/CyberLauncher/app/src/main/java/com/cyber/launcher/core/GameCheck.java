package com.cyber.launcher.core;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;

import java.io.File;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Looks at the real installed copy of the game: its apk files and whether it ships 64-bit libraries. */
public final class GameCheck {

    public static final class Info {
        public String packageName;
        public CharSequence label;
        public final List<String> apkPaths = new ArrayList<String>();   // base.apk first, then every split apk
        public String stamp;       // path:size:mtime of every apk; changes when the game is updated or its splits change
        public String libApk;      // file name of the apk that holds lib/arm64-v8a (often a split such as split_config.arm64_v8a.apk)
        public boolean has64;      // lib/arm64-v8a/*.so in the base apk or a split
        public boolean has32Only;  // only lib/armeabi-v7a
        public boolean hasIl2cpp;  // lib/arm64-v8a/libil2cpp.so (the menu's kTargetLib is libil2cpp.so)
    }

    private GameCheck() { }

    public static Info inspect(Context c, String pkg) throws PackageManager.NameNotFoundException {
        PackageManager pm = c.getPackageManager();
        ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
        Info i = new Info();
        i.packageName = pkg;
        i.label = pm.getApplicationLabel(ai);
        i.apkPaths.add(ai.sourceDir);
        if (ai.splitSourceDirs != null) {
            for (int k = 0; k < ai.splitSourceDirs.length; k++) i.apkPaths.add(ai.splitSourceDirs[k]);
        }
        StringBuilder st = new StringBuilder();
        for (int k = 0; k < i.apkPaths.size(); k++) {
            File f = new File(i.apkPaths.get(k));
            st.append(f.getPath()).append(':').append(f.length()).append(':').append(f.lastModified()).append('|');
        }
        i.stamp = st.toString();

        boolean arm32 = false;
        for (int k = 0; k < i.apkPaths.size(); k++) {
            ZipFile z = null;
            try {
                z = new ZipFile(new File(i.apkPaths.get(k)));
                Enumeration<? extends ZipEntry> e = z.entries();
                while (e.hasMoreElements()) {
                    String n = e.nextElement().getName();
                    if (!n.startsWith("lib/") || !n.endsWith(".so")) continue;
                    if (n.startsWith("lib/arm64-v8a/")) {
                        i.has64 = true;
                        if (i.libApk == null) i.libApk = new File(i.apkPaths.get(k)).getName();
                        if (n.equals("lib/arm64-v8a/libil2cpp.so")) i.hasIl2cpp = true;
                    } else if (n.startsWith("lib/armeabi-v7a/")) {
                        arm32 = true;
                    }
                }
            } catch (Exception ignored) {
            } finally {
                if (z != null) {
                    try { z.close(); } catch (Exception ignored2) { }
                }
            }
        }
        i.has32Only = arm32 && !i.has64;
        return i;
    }
}
