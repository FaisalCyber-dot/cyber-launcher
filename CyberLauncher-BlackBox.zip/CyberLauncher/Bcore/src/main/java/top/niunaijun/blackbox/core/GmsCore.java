package top.niunaijun.blackbox.core;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Build;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.entity.pm.InstallResult;
import top.niunaijun.blackbox.utils.Slog;


public class GmsCore {
    private static final String TAG = "GmsCore";

    private static final HashSet<String> GOOGLE_APP = new HashSet<>();
    private static final HashSet<String> GOOGLE_SERVICE = new HashSet<>();
    public static final String GMS_PKG = "com.google.android.gms";
    public static final String GSF_PKG = "com.google.android.gsf";
    public static final String VENDING_PKG = "com.android.vending";

    static {
        GOOGLE_APP.add(VENDING_PKG);
        GOOGLE_APP.add("com.google.android.play.games");
        GOOGLE_APP.add("com.google.android.wearable.app");
        GOOGLE_APP.add("com.google.android.wearable.app.cn");

        
        GOOGLE_SERVICE.add(GMS_PKG);
        GOOGLE_SERVICE.add(GSF_PKG);
        GOOGLE_SERVICE.add("com.google.android.gsf.login");
        GOOGLE_SERVICE.add("com.google.android.backuptransport");
        GOOGLE_SERVICE.add("com.google.android.backup");
        GOOGLE_SERVICE.add("com.google.android.configupdater");
        GOOGLE_SERVICE.add("com.google.android.syncadapters.contacts");
        GOOGLE_SERVICE.add("com.google.android.feedback");
        GOOGLE_SERVICE.add("com.google.android.onetimeinitializer");
        GOOGLE_SERVICE.add("com.google.android.partnersetup");
        GOOGLE_SERVICE.add("com.google.android.setupwizard");
        GOOGLE_SERVICE.add("com.google.android.syncadapters.calendar");
    }

    public static boolean isGoogleService(String packageName) {
        return GOOGLE_SERVICE.contains(packageName);
    }

    public static boolean isGoogleAppOrService(String str) {
        return GOOGLE_APP.contains(str) || GOOGLE_SERVICE.contains(str);
    }

    /** Only the Play services core is mandatory. Everything else Google ships is best-effort. */
    public static boolean isRequired(String packageName) {
        return GMS_PKG.equals(packageName);
    }

    /** Install order: core first, so a failure on the core aborts before anything else is touched. */
    private static List<String> orderedPackages() {
        LinkedHashSet<String> ordered = new LinkedHashSet<>();
        ordered.add(GMS_PKG);
        ordered.add(GSF_PKG);
        ordered.add("com.google.android.gsf.login");
        ordered.add(VENDING_PKG);
        ordered.addAll(GOOGLE_SERVICE);
        ordered.addAll(GOOGLE_APP);
        return new ArrayList<>(ordered);
    }

    private static PackageInfo hostInfo(String packageName) {
        try {
            return BlackBoxCore.getPackageManager().getPackageInfo(packageName, 0);
        } catch (Throwable ignored) {
            return null;
        }
    }

    private static void uninstallPackages(Set<String> list, int userId) {
        BlackBoxCore blackBoxCore = BlackBoxCore.get();
        for (String packageName : list) {
            blackBoxCore.uninstallPackageAsUser(packageName, userId);
        }
    }

    public static InstallResult installGApps(int userId) {
        InstallResult result = new InstallResult();

        // The box does not ship Google Play services. It copies the one installed on the phone.
        // Previously a phone without it "succeeded" with nothing installed.
        if (hostInfo(GMS_PKG) == null) {
            return result.installError(GMS_PKG,
                    "Google Play services (com.google.android.gms) is not installed on this phone. "
                            + "The box copies it from the phone, so install it on the phone first.");
        }

        BlackBoxCore blackBoxCore = BlackBoxCore.get();
        StringBuilder skipped = new StringBuilder();
        for (String packageName : orderedPackages()) {
            if (hostInfo(packageName) == null) {
                continue;
            }
            if (blackBoxCore.isInstalled(packageName, userId)) {
                continue;
            }
            InstallResult r = blackBoxCore.installPackageAsUser(packageName, userId);
            if (r != null && r.success) {
                continue;
            }
            String err = r != null ? r.msg : "unknown error";
            if (isRequired(packageName)) {
                // Core failed: roll back so we don't leave a half-installed Google stack behind.
                uninstallGApps(userId);
                return result.installError(packageName, "Could not install " + packageName + ": " + err);
            }
            // Optional package failed (e.g. a privileged setup app that cannot be cloned). The old
            // code rolled back the whole stack here, which is what made "Enable GMS" fail on phones
            // where one of these refuses to install.
            Slog.w(TAG, "Optional Google package skipped: " + packageName + " (" + err + ")");
            if (skipped.length() > 0) skipped.append(", ");
            skipped.append(packageName);
        }
        if (skipped.length() > 0) {
            result.msg = "Installed. Optional packages skipped: " + skipped;
        }
        return result;
    }

    // ---------------------------------------------------------------------------------------
    // Sync with the phone's Google Play services
    // ---------------------------------------------------------------------------------------

    private static String[] nz(String[] a) {
        return a == null ? new String[0] : a;
    }

    @SuppressWarnings("deprecation")
    private static int versionOf(PackageInfo pi) {
        return pi.versionCode;
    }

    /**
     * Why the box copy of {@code packageName} no longer matches the phone's copy, or null when it
     * matches (or there is nothing on the phone to compare against).
     */
    public static String staleReason(String packageName, int userId) {
        PackageInfo host = hostInfo(packageName);
        if (host == null || host.applicationInfo == null) {
            return null;
        }
        PackageInfo box = null;
        try {
            box = BlackBoxCore.getBPackageManager().getPackageInfo(packageName, 0, userId);
        } catch (Throwable ignored) {
        }
        if (box == null || box.applicationInfo == null) {
            return "box copy unreadable";
        }
        if (versionOf(box) != versionOf(host)) {
            return "version " + versionOf(box) + " -> " + versionOf(host);
        }
        String boxBase = box.applicationInfo.sourceDir;
        String hostBase = host.applicationInfo.sourceDir;
        if (boxBase == null || !boxBase.equals(hostBase)) {
            return "base APK path changed";
        }
        if (!Arrays.equals(nz(box.applicationInfo.splitSourceDirs), nz(host.applicationInfo.splitSourceDirs))) {
            return "split APKs changed";
        }
        return null;
    }

    /** True when GMS is enabled for the user and the phone's Google packages have moved on. */
    public static boolean isUpdateNeeded(int userId) {
        try {
            if (!isInstalledGoogleService(userId)) {
                return false;
            }
            for (String packageName : orderedPackages()) {
                if (hostInfo(packageName) == null) {
                    continue;
                }
                if (!BlackBoxCore.get().isInstalled(packageName, userId)) {
                    continue;
                }
                if (staleReason(packageName, userId) != null) {
                    return true;
                }
            }
        } catch (Throwable t) {
            Slog.w(TAG, "isUpdateNeeded failed", t);
        }
        return false;
    }

    /**
     * Re-syncs the box's Google packages with the phone's, in place. User data (accounts, GMS
     * databases) is kept: the install path only recreates the code entry, not the data dirs.
     */
    public static InstallResult updateGApps(int userId) {
        InstallResult result = new InstallResult();
        BlackBoxCore blackBoxCore = BlackBoxCore.get();

        if (hostInfo(GMS_PKG) == null) {
            return result.installError(GMS_PKG,
                    "Google Play services is not installed on this phone, so there is nothing to sync from.");
        }
        if (!blackBoxCore.isInstalled(GMS_PKG, userId)) {
            return result.installError(GMS_PKG, "GMS is not enabled for this user. Enable it first.");
        }

        StringBuilder changes = new StringBuilder();
        StringBuilder failed = new StringBuilder();
        int updated = 0;
        for (String packageName : orderedPackages()) {
            if (hostInfo(packageName) == null) {
                continue;
            }
            boolean inBox = blackBoxCore.isInstalled(packageName, userId);
            String reason = inBox ? staleReason(packageName, userId) : "new on phone";
            if (reason == null) {
                continue;
            }
            InstallResult r = blackBoxCore.installPackageAsUser(packageName, userId);
            if (r != null && r.success) {
                updated++;
                changes.append("\n- ").append(packageName).append(": ").append(reason);
                continue;
            }
            String err = r != null ? r.msg : "unknown error";
            if (isRequired(packageName)) {
                return result.installError(packageName, "Could not update " + packageName + ": " + err);
            }
            Slog.w(TAG, "Optional Google package not updated: " + packageName + " (" + err + ")");
            if (failed.length() > 0) failed.append(", ");
            failed.append(packageName);
        }

        StringBuilder msg = new StringBuilder();
        msg.append(updated == 0 ? "Google services already match the phone." : "Updated " + updated + " package(s):" + changes);
        if (failed.length() > 0) {
            msg.append("\nNot updated (optional): ").append(failed);
        }
        result.msg = msg.toString();
        return result;
    }

    // ---------------------------------------------------------------------------------------
    // Diagnostics: a report you can share from a phone, no PC needed
    // ---------------------------------------------------------------------------------------

    private static String fileState(String path) {
        if (path == null) return "null";
        return new File(path).exists() ? "exists" : "MISSING";
    }

    private static String describe(PackageInfo pi) {
        if (pi == null || pi.applicationInfo == null) return "n/a";
        StringBuilder sb = new StringBuilder();
        sb.append("v").append(versionOf(pi)).append(" ").append(pi.versionName);
        sb.append("\n      base=").append(pi.applicationInfo.sourceDir).append(" [").append(fileState(pi.applicationInfo.sourceDir)).append("]");
        String[] splits = pi.applicationInfo.splitSourceDirs;
        if (splits != null) {
            for (String s : splits) {
                sb.append("\n      split=").append(s).append(" [").append(fileState(s)).append("]");
            }
        }
        return sb.toString();
    }

    public static String buildReport(int userId) {
        StringBuilder sb = new StringBuilder();
        sb.append("GMS REPORT  ").append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date())).append("\n");
        sb.append("Android ").append(Build.VERSION.RELEASE).append(" (SDK ").append(Build.VERSION.SDK_INT).append(")  ")
                .append(Build.MANUFACTURER).append(" ").append(Build.MODEL).append("  ABIs=").append(Arrays.toString(Build.SUPPORTED_ABIS)).append("\n");
        sb.append("Host package: ").append(BlackBoxCore.getHostPkg()).append("   box user: ").append(userId).append("\n");
        boolean enabled = false;
        try {
            enabled = isInstalledGoogleService(userId);
        } catch (Throwable ignored) {
        }
        sb.append("GMS enabled in box: ").append(enabled).append("   update needed: ").append(isUpdateNeeded(userId)).append("\n\n");

        for (String packageName : orderedPackages()) {
            PackageInfo host = hostInfo(packageName);
            boolean inBox = false;
            try {
                inBox = BlackBoxCore.get().isInstalled(packageName, userId);
            } catch (Throwable ignored) {
            }
            if (host == null && !inBox) {
                continue;
            }
            sb.append(packageName).append(isRequired(packageName) ? "  (required)" : "").append("\n");
            sb.append("  phone: ").append(describe(host)).append("\n");
            PackageInfo box = null;
            if (inBox) {
                try {
                    box = BlackBoxCore.getBPackageManager().getPackageInfo(packageName, 0, userId);
                } catch (Throwable ignored) {
                }
            }
            sb.append("  box:   ").append(inBox ? describe(box) : "not installed").append("\n");
            if (inBox && host != null) {
                String reason = staleReason(packageName, userId);
                sb.append("  sync:  ").append(reason == null ? "OK" : "STALE (" + reason + ")").append("\n");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    /** Matches the lines that matter when Play services misbehaves; keeps the report small. */
    private static boolean isInteresting(String line) {
        String l = line.toLowerCase(Locale.US);
        return l.contains("gms") || l.contains("gsf") || l.contains("vending") || l.contains("chimera")
                || l.contains("dynamite") || l.contains("googleapi") || l.contains("fatal exception")
                || l.contains("androidruntime") || l.contains("simplecrashfix") || l.contains("gmscore")
                || l.contains("bpackagemanager");
    }

    /**
     * Writes the report plus the relevant logcat lines (last ~4000) to cache/shared_logs so the
     * settings screen's FileProvider can share it. Returns the file, or null on failure.
     */
    public static File exportReport(int userId) {
        try {
            File dir = new File(BlackBoxCore.getContext().getCacheDir(), "shared_logs");
            if (!dir.exists() && !dir.mkdirs()) {
                return null;
            }
            File out = new File(dir, "gms_report_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date()) + ".txt");

            ArrayDeque<String> tail = new ArrayDeque<>();
            Process process = null;
            try {
                process = Runtime.getRuntime().exec(new String[]{"logcat", "-d", "-v", "threadtime"});
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (isInteresting(line)) {
                            if (tail.size() >= 4000) {
                                tail.removeFirst();
                            }
                            tail.addLast(line);
                        }
                    }
                }
            } catch (Throwable t) {
                tail.addLast("(logcat unavailable: " + t + ")");
            } finally {
                if (process != null) {
                    process.destroy();
                }
            }

            try (FileOutputStream fos = new FileOutputStream(out)) {
                fos.write(buildReport(userId).getBytes(StandardCharsets.UTF_8));
                fos.write("\n--- RELEVANT LOGCAT ---\n".getBytes(StandardCharsets.UTF_8));
                for (String line : tail) {
                    fos.write(line.getBytes(StandardCharsets.UTF_8));
                    fos.write('\n');
                }
            }
            return out;
        } catch (Throwable t) {
            Slog.e(TAG, "exportReport failed", t);
            return null;
        }
    }

    public static void uninstallGApps(int userId) {
        uninstallPackages(GOOGLE_SERVICE, userId);
        uninstallPackages(GOOGLE_APP, userId);
    }

    public static boolean hasGmsTraces(int userId) {
        BlackBoxCore blackBoxCore = BlackBoxCore.get();

        Set<String> known = new HashSet<>();
        known.addAll(GOOGLE_SERVICE);
        known.addAll(GOOGLE_APP);

        for (String pkg : known) {
            try {
                if (blackBoxCore.isInstalled(pkg, userId)) {
                    return true;
                }
            } catch (Throwable ignored) {
            }
        }

        try {
            List<PackageInfo> installed = blackBoxCore.getInstalledPackages(0, userId);
            for (PackageInfo pi : installed) {
                if (pi == null || pi.packageName == null) {
                    continue;
                }
                String pkg = pi.packageName;
                if (VENDING_PKG.equals(pkg) || pkg.startsWith("com.google.android.")) {
                    return true;
                }
            }
        } catch (Throwable ignored) {
        }

        return false;
    }

    /**
     * Best-effort cleanup: clears package data and uninstalls known Google packages
     * for the given virtual user. Intended for "wipe" UX.
     */
    public static void wipeGApps(int userId) {
        BlackBoxCore blackBoxCore = BlackBoxCore.get();

        Set<String> toRemove = new HashSet<>();
        toRemove.addAll(GOOGLE_SERVICE);
        toRemove.addAll(GOOGLE_APP);

        try {
            List<PackageInfo> installed = blackBoxCore.getInstalledPackages(0, userId);
            for (PackageInfo pi : installed) {
                if (pi == null || pi.packageName == null) {
                    continue;
                }
                String pkg = pi.packageName;
                if (VENDING_PKG.equals(pkg) || pkg.startsWith("com.google.android.")) {
                    toRemove.add(pkg);
                }
            }
        } catch (Throwable ignored) {
        }

        for (String pkg : toRemove) {
            try {
                blackBoxCore.clearPackage(pkg, userId);
            } catch (Throwable ignored) {
            }
        }

        for (String pkg : toRemove) {
            try {
                blackBoxCore.uninstallPackageAsUser(pkg, userId);
            } catch (Throwable ignored) {
            }
        }
    }

    public static void remove(String packageName) {
        GOOGLE_SERVICE.remove(packageName);
        GOOGLE_APP.remove(packageName);
    }


    public static boolean isSupportGms() {
        try {
            BlackBoxCore.getPackageManager().getPackageInfo(GMS_PKG, 0);
            return true;
        } catch (PackageManager.NameNotFoundException ignored) {
        }
        return false;
    }

    public static boolean isInstalledGoogleService(int userId) {
        return BlackBoxCore.get().isInstalled(GMS_PKG, userId);
    }
}