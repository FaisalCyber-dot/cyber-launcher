package com.cyber.launcher.ui;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * The launcher's own keyboard. The Android keyboard is never opened: the text field has
 * setShowSoftInputOnFocus(false) and this view types into it directly. Has a PASTE key.
 */
public class CyberKeyboardView extends LinearLayout {

    private static final String[] L1 = {"q", "w", "e", "r", "t", "y", "u", "i", "o", "p"};
    private static final String[] L2 = {"a", "s", "d", "f", "g", "h", "j", "k", "l"};
    private static final String[] L3 = {"z", "x", "c", "v", "b", "n", "m"};
    private static final String[] S1 = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
    private static final String[] S2 = {"@", "#", "$", "%", "&", "-", "+", "(", ")", "="};
    private static final String[] S3 = {"_", "*", "\"", "'", ":", ";", "!", "?", "/"};

    private static final int KEY_BG = 0xFF1E1B1F, KEY_PRESSED = 0xFF4A1318, SPECIAL_BG = 0xFF151215;
    private static final int TEXT = 0xFFF2EEF0, ACCENT = 0xFFE53935;

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final float d;
    private EditText target;
    private Runnable onDone;
    private boolean symbols, shift;

    public CyberKeyboardView(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        setOrientation(VERTICAL);
        setBackgroundColor(0xFF0E0C0E);
        int p = dp(4);
        setPadding(p, p, p, dp(8));
        rebuild();
    }

    public void setTarget(EditText t) { target = t; }
    public void setOnDone(Runnable r) { onDone = r; }

    // ------------------------------------------------------------------ layout
    private int dp(int v) { return Math.round(v * d); }

    private void rebuild() {
        removeAllViews();
        if (!symbols) {
            addRow(letters(L1));
            addRow(spacer(0.5f), letters(L2), spacer(0.5f));
            addRow(special("\u21E7", 1.5f, new Runnable() { @Override public void run() { shift = !shift; rebuild(); } }, shift),
                    letters(L3),
                    backspace(1.5f));
        } else {
            addRow(chars(S1));
            addRow(chars(S2));
            addRow(chars(S3), backspace(1f));
        }
        addRow(
                special(symbols ? "ABC" : "?123", 1.6f, new Runnable() { @Override public void run() { symbols = !symbols; shift = false; rebuild(); } }, false),
                key(".", 1f, ".", false),
                key("_", 1f, "_", false),
                key("space", 3.4f, " ", false),
                accent("PASTE", 1.6f, new Runnable() { @Override public void run() { insert(clipboardLine(getContext())); } }),
                accent("DONE", 1.4f, new Runnable() { @Override public void run() { if (onDone != null) onDone.run(); } }));
    }

    private View[] letters(String[] a) {
        View[] v = new View[a.length];
        for (int i = 0; i < a.length; i++) {
            final String ch = shift ? a[i].toUpperCase() : a[i];
            v[i] = key(ch, 1f, ch, true);
        }
        return v;
    }

    private View[] chars(String[] a) {
        View[] v = new View[a.length];
        for (int i = 0; i < a.length; i++) v[i] = key(a[i], 1f, a[i], false);
        return v;
    }

    private void addRow(Object... parts) {
        LinearLayout row = new LinearLayout(getContext());
        row.setOrientation(HORIZONTAL);
        for (Object o : parts) {
            if (o instanceof View) row.addView((View) o);
            else for (View v : (View[]) o) row.addView(v);
        }
        addView(row, new LayoutParams(LayoutParams.MATCH_PARENT, dp(48)));
    }

    private View spacer(float w) {
        View v = new View(getContext());
        v.setLayoutParams(new LayoutParams(0, LayoutParams.MATCH_PARENT, w));
        return v;
    }

    private TextView base(String label, float weight, int bg, int color) {
        TextView t = new TextView(getContext());
        t.setText(label);
        t.setTextColor(color);
        t.setTextSize(label.length() > 1 ? 14 : 19);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setClickable(true);
        t.setBackground(keyBg(bg));
        LayoutParams lp = new LayoutParams(0, LayoutParams.MATCH_PARENT, weight);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        t.setLayoutParams(lp);
        return t;
    }

    private StateListDrawable keyBg(int normal) {
        StateListDrawable s = new StateListDrawable();
        GradientDrawable pressed = new GradientDrawable();
        pressed.setColor(KEY_PRESSED);
        pressed.setCornerRadius(dp(8));
        GradientDrawable n = new GradientDrawable();
        n.setColor(normal);
        n.setCornerRadius(dp(8));
        s.addState(new int[]{android.R.attr.state_pressed}, pressed);
        s.addState(new int[]{}, n);
        return s;
    }

    private TextView key(String label, float weight, final String insertText, final boolean letter) {
        TextView t = base(label, weight, KEY_BG, TEXT);
        t.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) {
                insert(insertText);
                if (letter && shift) { shift = false; rebuild(); }
            }
        });
        return t;
    }

    private TextView special(String label, float weight, final Runnable r, boolean on) {
        TextView t = base(label, weight, SPECIAL_BG, on ? ACCENT : TEXT);
        t.setOnClickListener(new OnClickListener() { @Override public void onClick(View v) { r.run(); } });
        return t;
    }

    private TextView accent(String label, float weight, final Runnable r) {
        TextView t = base(label, weight, SPECIAL_BG, ACCENT);
        t.setOnClickListener(new OnClickListener() { @Override public void onClick(View v) { r.run(); } });
        return t;
    }

    private TextView backspace(float weight) {
        TextView t = base("\u232B", weight, SPECIAL_BG, TEXT);
        final Runnable repeat = new Runnable() {
            @Override public void run() {
                deleteBack();
                ui.postDelayed(this, 55);
            }
        };
        t.setOnTouchListener(new OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        v.setPressed(true);
                        deleteBack();
                        ui.postDelayed(repeat, 400);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        v.setPressed(false);
                        ui.removeCallbacks(repeat);
                        return true;
                }
                return true;
            }
        });
        return t;
    }

    // ------------------------------------------------------------------ typing
    private void insert(String s) {
        EditText t = target;
        if (t == null || s == null || s.isEmpty()) return;
        Editable e = t.getText();
        int a = t.getSelectionStart(), b = t.getSelectionEnd();
        if (a < 0 || b < 0) { a = b = e.length(); }
        e.replace(Math.min(a, b), Math.max(a, b), s);
    }

    private void deleteBack() {
        EditText t = target;
        if (t == null) return;
        Editable e = t.getText();
        int a = t.getSelectionStart(), b = t.getSelectionEnd();
        if (a < 0 || b < 0) { a = b = e.length(); }
        int lo = Math.min(a, b), hi = Math.max(a, b);
        if (lo != hi) e.delete(lo, hi);
        else if (lo > 0) e.delete(lo - 1, lo);
    }

    // ------------------------------------------------------------------ clipboard
    /** Clipboard text, whitespace stripped and cut to its first line. Null when the clipboard has no text. */
    public static String clipboardLine(Context c) {
        try {
            ClipboardManager cm = (ClipboardManager) c.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip()) return null;
            ClipData cd = cm.getPrimaryClip();
            if (cd == null || cd.getItemCount() == 0) return null;
            CharSequence t = cd.getItemAt(0).coerceToText(c);
            if (t == null) return null;
            String s = t.toString().trim();
            int nl = s.indexOf('\n');
            if (nl >= 0) s = s.substring(0, nl).trim();
            return s.isEmpty() ? null : s;
        } catch (Throwable ignored) {
            return null;
        }
    }
}
