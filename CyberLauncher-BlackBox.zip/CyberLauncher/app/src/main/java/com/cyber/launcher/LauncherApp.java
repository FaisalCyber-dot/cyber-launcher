package com.cyber.launcher;

import android.app.Application;
import android.content.Context;

import com.cyber.launcher.engine.EngineProvider;

/**
 * Runs in the launcher process and also in every guest process (the engine runs the guest inside
 * processes of this APK). hostFilesDir is the launcher's own private folder: the guest side reads
 * the staged menu library from there, because the guest's own getFilesDir() is a different folder.
 */
public class LauncherApp extends Application {

    private static volatile String hostFilesDir;

    public static String hostFilesDir() { return hostFilesDir; }

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        try { hostFilesDir = base.getFilesDir().getAbsolutePath(); } catch (Throwable ignored) { }
        EngineProvider.get().attachBaseContext(base);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        EngineProvider.get().onCreate(this);
    }
}
