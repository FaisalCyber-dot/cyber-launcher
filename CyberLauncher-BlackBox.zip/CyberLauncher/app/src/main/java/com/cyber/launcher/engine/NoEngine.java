package com.cyber.launcher.engine;

import android.app.Application;
import android.content.Context;

import java.util.List;

/** Placeholder so the project builds before an engine is connected. Every action reports it honestly. */
public final class NoEngine implements GuestEngine {

    private static IllegalStateException missing() {
        return new IllegalStateException("No virtual engine is connected yet. Implement GuestEngine and return it from EngineProvider (see ENGINE.md).");
    }

    @Override public String name() { return "none"; }
    @Override public void attachBaseContext(Context base) { }
    @Override public void onCreate(Application app) { }
    @Override public boolean isGuestInstalled(String packageName) { return false; }
    @Override public void installGuest(String packageName, List<String> hostApkPaths) { throw missing(); }
    @Override public void stopGuest(String packageName) { }
    @Override public void launchGuest(String packageName) { throw missing(); }
}
