package com.cyber.launcher.core;

import android.content.Context;
import android.os.Environment;

import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** The CyberLauncher folder, ELF validation, and the private read-only copy the guest process loads. (AIDE-safe Java: no lambdas, no try-with-resources, no diamond) */
public final class LibStore {

    public static final String FOLDER = "CyberLauncher";
    public static final String ACTIVE_FILE = "active.txt";   // staged lib path, or "off"

    private LibStore() { }

    private static void close(Closeable c) {
        if (c == null) return;
        try { c.close(); } catch (IOException ignored) { }
    }

    public static File sharedDir() {
        return new File(Environment.getExternalStorageDirectory(), FOLDER);
    }

    /** Optional universal apk of a game: CyberLauncher/<package>.apk (used for split installs / games not installed on the phone). */
    public static File universalApk(String packageName) {
        return new File(sharedDir(), packageName + ".apk");
    }

    public static boolean ensureSharedDir() {
        File d = sharedDir();
        return d.isDirectory() || d.mkdirs();
    }

    public static List<File> list() {
        File[] f = sharedDir().listFiles();
        List<File> out = new ArrayList<File>();
        if (f == null) return out;
        for (int i = 0; i < f.length; i++) {
            File x = f[i];
            if (x.isFile() && x.getName().toLowerCase(Locale.ROOT).endsWith(".so")) out.add(x);
        }
        Collections.sort(out, new Comparator<File>() {
            @Override public int compare(File p, File q) { return p.getName().compareToIgnoreCase(q.getName()); }
        });
        return out;
    }

    /** Returns null when the file is a 64-bit ARM shared object, otherwise a readable reason. */
    public static String check(File f) {
        RandomAccessFile r = null;
        try {
            r = new RandomAccessFile(f, "r");
            byte[] h = new byte[20];
            r.readFully(h);
            if (h[0] != 0x7F || h[1] != 'E' || h[2] != 'L' || h[3] != 'F') return "Not an ELF file.";
            if (h[4] != 2) return "Not a 64-bit library (this launcher is 64-bit only).";
            if (h[5] != 1) return "Not a little-endian library.";
            int type = (h[16] & 0xFF) | ((h[17] & 0xFF) << 8);
            int machine = (h[18] & 0xFF) | ((h[19] & 0xFF) << 8);
            if (type != 3) return "Not a shared object (ET_DYN).";
            if (machine != 183) return "Not an arm64 library (EM_AARCH64 expected).";
            return null;
        } catch (IOException e) {
            return "Cannot read the file: " + e.getMessage();
        } finally {
            close(r);
        }
    }

    public static File stagedDir(Context c) {
        File d = new File(c.getFilesDir(), "menu");
        if (!d.isDirectory()) d.mkdirs();
        return d;
    }

    /**
     * Copies the library into the launcher's private folder as a read-only file whose name carries
     * size + modification time, so a replaced library is never confused with the old one.
     * (Android 14+ also wants dynamically loaded files to be read-only.)
     */
    public static File stage(Context c, File src) throws IOException {
        File dir = stagedDir(c);
        String base = src.getName();
        if (base.toLowerCase(Locale.ROOT).endsWith(".so")) base = base.substring(0, base.length() - 3);
        base = base.replaceAll("[^A-Za-z0-9._-]", "_");
        File dst = new File(dir, base + "_" + Long.toHexString(src.length()) + "_" + Long.toHexString(src.lastModified()) + ".so");

        if (!dst.isFile() || dst.length() != src.length()) {
            File tmp = new File(dir, dst.getName() + ".tmp");
            if (tmp.exists() && !tmp.delete()) throw new IOException("Cannot clear " + tmp);
            FileInputStream in = null;
            FileOutputStream out = null;
            try {
                in = new FileInputStream(src);
                out = new FileOutputStream(tmp);
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.getFD().sync();
            } finally {
                close(in);
                close(out);
            }
            tmp.setReadOnly();
            if (dst.exists()) dst.delete();
            if (!tmp.renameTo(dst)) throw new IOException("Cannot move the staged library into place");
        }
        File[] all = dir.listFiles();
        if (all != null) {
            for (int i = 0; i < all.length; i++) {
                File o = all[i];
                if (!o.equals(dst) && o.getName().endsWith(".so")) o.delete();
            }
        }
        return dst;
    }

    /** staged == null writes "off": the guest will not load anything. */
    public static void writeActive(Context c, File staged) throws IOException {
        File dir = stagedDir(c);
        File tmp = new File(dir, ACTIVE_FILE + ".tmp");
        FileOutputStream out = null;
        try {
            out = new FileOutputStream(tmp);
            out.write((staged == null ? "off" : staged.getAbsolutePath()).getBytes("UTF-8"));
            out.getFD().sync();
        } finally {
            close(out);
        }
        File dst = new File(dir, ACTIVE_FILE);
        if (!tmp.renameTo(dst)) throw new IOException("Cannot write " + dst);
    }

    /** Used by the guest side. Returns an absolute library path, or null when injection is off. */
    public static String readActive(String hostFilesDir) {
        if (hostFilesDir == null) return null;
        File f = new File(new File(hostFilesDir, "menu"), ACTIVE_FILE);
        RandomAccessFile r = null;
        try {
            r = new RandomAccessFile(f, "r");
            byte[] b = new byte[(int) Math.min(r.length(), 4096L)];
            r.readFully(b);
            String s = new String(b, "UTF-8").trim();
            if (s.length() == 0 || s.equals("off")) return null;
            return new File(s).isFile() ? s : null;
        } catch (IOException e) {
            return null;
        } finally {
            close(r);
        }
    }
}
