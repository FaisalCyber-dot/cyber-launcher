package com.cyber.launcher;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Process;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.cyber.launcher.core.GameCheck;
import com.cyber.launcher.core.LibStore;
import com.cyber.launcher.core.LogFiles;
import com.cyber.launcher.engine.EngineProvider;
import com.cyber.launcher.engine.GuestEngine;
import com.cyber.launcher.ui.CyberKeyboardView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class MainActivity extends Activity {

    private static final String PREFS = "cyber_launcher";
    private static final String DEFAULT_PKG = "com.dvloper.granny";
    private static final Pattern PKG = Pattern.compile("^[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z0-9_]+)+$");

    private static final int BG = 0xFF0C0A0B, CARD = 0xFF151213, LINE = 0xFF4A4448;
    private static final int WHITE = 0xFFF4F0F2, GRAY = 0xFF9A9296, RED = 0xFFE53935;

    private SharedPreferences prefs;
    private ScrollView scroll;
    private LinearLayout content;
    private EditText pkgField;
    private Spinner libSpinner;
    private Switch injectSwitch;
    private Button launchBtn, allowBtn;
    private TextView status, footer;
    private CyberKeyboardView keyboard;

    private List<File> libs = new ArrayList<File>();
    private boolean busy;

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    // ------------------------------------------------------------------ UI
    @Override
    protected void onCreate(android.os.Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
                | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setFocusableInTouchMode(true);
        content.setPadding(dp(18), dp(28), dp(18), dp(18));
        scroll.addView(content, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackgroundColor(CARD);
        content.addView(card, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("Developer", 22, WHITE, true);
        card.addView(title);
        card.addView(text("Launch a game by entering its package name.", 14, GRAY, false), lp(0, 4, 0, 14));

        // package name + paste
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(row, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        pkgField = new EditText(this);
        pkgField.setHint("Package name");
        pkgField.setHintTextColor(GRAY);
        pkgField.setTextColor(WHITE);
        pkgField.setTextSize(17);
        pkgField.setSingleLine(true);
        pkgField.setShowSoftInputOnFocus(false);              // the Android keyboard never opens for this field
        pkgField.setBackground(box(LINE, 0, 6));
        pkgField.setPadding(dp(14), dp(14), dp(14), dp(14));
        pkgField.setText(prefs.getString("pkg", DEFAULT_PKG));
        pkgField.setSelection(pkgField.getText().length());
        row.addView(pkgField, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button paste = outlined("PASTE", RED);
        paste.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String t = CyberKeyboardView.clipboardLine(MainActivity.this);
                if (t == null) { toast("Clipboard is empty"); return; }
                pkgField.setText(t);
                pkgField.setSelection(pkgField.getText().length());
            }
        });
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(52));
        plp.leftMargin = dp(8);
        row.addView(paste, plp);

        // library picker
        card.addView(text("SO library from CyberLauncher", 13, GRAY, false), lp(0, 16, 0, 6));
        LinearLayout libRow = new LinearLayout(this);
        libRow.setOrientation(LinearLayout.HORIZONTAL);
        libRow.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(libRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        FrameLayout spBox = new FrameLayout(this);
        spBox.setBackground(box(LINE, 0, 6));
        libSpinner = new Spinner(this);
        if (libSpinner.getBackground() != null) libSpinner.getBackground().setColorFilter(0xFFCFC8CC, PorterDuff.Mode.SRC_ATOP);
        spBox.addView(libSpinner, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52)));
        libRow.addView(spBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button refresh = outlined("REFRESH", GRAY);
        refresh.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { refreshLibs(); } });
        LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(52));
        rlp.leftMargin = dp(8);
        libRow.addView(refresh, rlp);

        status = text("", 13, GRAY, false);
        card.addView(status, lp(0, 8, 0, 0));

        allowBtn = outlined("ALLOW ACCESS TO THE CYBERLAUNCHER FOLDER", RED);
        allowBtn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { requestStorage(); } });
        card.addView(allowBtn, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        // inject switch
        LinearLayout sw = new LinearLayout(this);
        sw.setOrientation(LinearLayout.HORIZONTAL);
        sw.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout swText = new LinearLayout(this);
        swText.setOrientation(LinearLayout.VERTICAL);
        swText.addView(text("Inject menu", 18, WHITE, true));
        swText.addView(text("Use the selected SO library from the CyberLauncher folder", 13, GRAY, false), lp(0, 2, 0, 0));
        sw.addView(swText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        injectSwitch = new Switch(this);
        injectSwitch.setChecked(prefs.getBoolean("inject", true));
        sw.addView(injectSwitch);
        card.addView(sw, lp(0, 18, 0, 0));

        launchBtn = outlined("LAUNCH", RED);
        launchBtn.setTextSize(18);
        launchBtn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { launch(); } });
        card.addView(launchBtn, lpSize(ViewGroup.LayoutParams.MATCH_PARENT, 56, 0, 18, 0, 0));

        Button logs = outlined("CRASH LOGS", GRAY);
        logs.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showLogs(); } });
        card.addView(logs, lpSize(ViewGroup.LayoutParams.MATCH_PARENT, 50, 0, 10, 0, 0));

        footer = text("", 12, GRAY, false);
        content.addView(footer, lp(4, 14, 4, 0));

        // custom keyboard
        keyboard = new CyberKeyboardView(this);
        keyboard.setTarget(pkgField);
        keyboard.setOnDone(new Runnable() { @Override public void run() { hideKeyboard(); } });
        keyboard.setVisibility(View.GONE);
        root.addView(keyboard, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        pkgField.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override public void onFocusChange(View v, boolean has) { if (has) showKeyboard(); }
        });
        pkgField.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { showKeyboard(); } });

        libSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                if (pos >= 0 && pos < libs.size()) prefs.edit().putString("lib", libs.get(pos).getName()).apply();
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });

        setContentView(root);
        refreshFooter();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshLibs();     // also after coming back from the "all files access" screen
    }

    @Override
    protected void onPause() {
        prefs.edit().putString("pkg", pkgField.getText().toString().trim()).putBoolean("inject", injectSwitch.isChecked()).apply();
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (keyboard.getVisibility() == View.VISIBLE) hideKeyboard(); else super.onBackPressed();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        refreshLibs();
    }

    // ------------------------------------------------------------------ keyboard
    private void showKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(pkgField.getWindowToken(), 0);   // in case an OEM opened it anyway
        keyboard.setVisibility(View.VISIBLE);
        scroll.post(new Runnable() { @Override public void run() { scroll.smoothScrollTo(0, 0); } });
    }

    private void hideKeyboard() {
        keyboard.setVisibility(View.GONE);
        pkgField.clearFocus();
        content.requestFocus();
    }

    // ------------------------------------------------------------------ storage + libraries
    /** Environment.isExternalStorageManager() through reflection, so an older android.jar (AIDE) still compiles. */
    private boolean isStorageManager() {
        try {
            return ((Boolean) Environment.class.getMethod("isExternalStorageManager").invoke(null)).booleanValue();
        } catch (Throwable t) {
            return false;
        }
    }

    private boolean hasStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30) return isStorageManager();
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(new Intent("android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION", Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent("android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"));
            }
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
        }
    }

    private void refreshLibs() {
        boolean access = hasStorageAccess();
        allowBtn.setVisibility(access ? View.GONE : View.VISIBLE);
        libs = new ArrayList<File>();
        if (!access) {
            setStatus("Storage access is needed to read " + LibStore.sharedDir().getAbsolutePath(), true);
        } else {
            LibStore.ensureSharedDir();
            libs = LibStore.list();
            if (libs.isEmpty()) setStatus("Put your .so file into " + LibStore.sharedDir().getAbsolutePath() + " and press REFRESH.", false);
            else setStatus(libs.size() + (libs.size() == 1 ? " library" : " libraries") + " in " + LibStore.sharedDir().getAbsolutePath(), false);
        }

        List<String> names = new ArrayList<String>();
        for (File f : libs) names.add(f.getName());
        if (names.isEmpty()) names.add("(no .so file found)");
        ArrayAdapter<String> ad = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, names) {
            @Override public View getView(int p, View v, ViewGroup g) {
                TextView t = (TextView) super.getView(p, v, g);
                t.setTextColor(WHITE);
                t.setTextSize(17);
                return t;
            }
            @Override public View getDropDownView(int p, View v, ViewGroup g) {
                TextView t = (TextView) super.getDropDownView(p, v, g);
                t.setTextColor(WHITE);
                t.setBackgroundColor(0xFF1A1719);
                t.setPadding(dp(16), dp(12), dp(16), dp(12));
                return t;
            }
        };
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        libSpinner.setAdapter(ad);

        String saved = prefs.getString("lib", null);
        int sel = 0;
        for (int i = 0; i < libs.size(); i++) {
            String n = libs.get(i).getName();
            if (n.equals(saved)) { sel = i; break; }
            if (saved == null && n.toLowerCase().contains("cybercrimson")) sel = i;
        }
        if (!libs.isEmpty()) libSpinner.setSelection(sel);
    }

    // ------------------------------------------------------------------ launch
    private void launch() {
        if (busy) return;
        final String pkg = pkgField.getText().toString().trim();
        if (!PKG.matcher(pkg).matches()) { setStatus("That is not a valid package name.", true); return; }
        if (Build.SUPPORTED_64_BIT_ABIS.length == 0 || !Process.is64Bit()) { setStatus("This launcher is 64-bit only and this device/process is not 64-bit.", true); return; }

        final boolean inject = injectSwitch.isChecked();
        File picked = null;
        if (inject) {
            if (!hasStorageAccess()) { requestStorage(); return; }
            int pos = libSpinner.getSelectedItemPosition();
            if (libs.isEmpty() || pos < 0 || pos >= libs.size()) { setStatus("No .so file selected. Put it into " + LibStore.sharedDir().getAbsolutePath(), true); return; }
            picked = libs.get(pos);
            String err = LibStore.check(picked);
            if (err != null) { setStatus(picked.getName() + ": " + err, true); return; }
        }
        final File lib = picked;

        busy = true;
        launchBtn.setEnabled(false);
        hideKeyboard();
        setStatus("Preparing...", false);

        new Thread(new Runnable() {
            @Override public void run() {
                String warn = null;
                try {
                    GuestEngine engine = EngineProvider.get();
                    File uni = LibStore.universalApk(pkg);
                    GameCheck.Info gi = null;
                    try {
                        gi = GameCheck.inspect(MainActivity.this, pkg);
                    } catch (PackageManager.NameNotFoundException e) {
                        if (!engine.isGuestInstalled(pkg) && !uni.isFile()) throw new IllegalStateException("The game is not installed on this device: " + pkg
                                + ". Install it, or put " + uni.getName() + " into " + LibStore.sharedDir().getAbsolutePath());
                    }
                    if (gi != null) {
                        if (!gi.has64) throw new IllegalStateException(gi.has32Only
                                ? "This game only ships 32-bit libraries. The launcher supports 64-bit games only."
                                : "No lib/arm64-v8a libraries found in this game.");
                        if (!gi.hasIl2cpp && inject) warn = "Note: no libil2cpp.so in this game, the menu opens but its IL2CPP features will not find anything.";
                    }

                    engine.stopGuest(pkg);                                  // fresh process: the menu lib is loaded once per process
                    File staged = inject ? LibStore.stage(MainActivity.this, lib) : null;
                    LibStore.writeActive(MainActivity.this, staged);

                    // a changed CyberLauncher/<pkg>.apk is installed again, otherwise the old clone would keep running
                    String stamp = uni.isFile() ? uni.length() + ":" + uni.lastModified() : null;
                    boolean stale = stamp != null && !stamp.equals(prefs.getString("apk_" + pkg, null));
                    if (!engine.isGuestInstalled(pkg) || stale) {
                        post("Cloning " + pkg + " into the virtual space...", false);
                        engine.installGuest(pkg, gi != null ? gi.apkPaths : new ArrayList<String>());
                        if (stamp != null) prefs.edit().putString("apk_" + pkg, stamp).apply();
                        else prefs.edit().remove("apk_" + pkg).apply();
                    }
                    engine.launchGuest(pkg);
                    post(warn != null ? "Launched. " + warn : "Launched" + (inject ? " with " + lib.getName() : " without the menu"), false);
                } catch (Throwable t) {
                    post(t.getMessage() != null ? t.getMessage() : t.toString(), true);
                } finally {
                    runOnUiThread(new Runnable() { @Override public void run() { busy = false; launchBtn.setEnabled(true); } });
                }
            }
        }, "cyber-launch").start();
    }

    private void post(final String msg, final boolean error) {
        runOnUiThread(new Runnable() { @Override public void run() { setStatus(msg, error); } });
    }

    // ------------------------------------------------------------------ crash logs
    private void showLogs() {
        setStatus("Reading logs...", false);
        new Thread(new Runnable() {
            @Override public void run() {
                final String s = LogFiles.collect(MainActivity.this);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        setStatus("", false);
                        TextView tv = text(s, 11, WHITE, false);
                        tv.setTypeface(Typeface.MONOSPACE);
                        tv.setTextIsSelectable(true);
                        tv.setPadding(dp(12), dp(12), dp(12), dp(12));
                        ScrollView sv = new ScrollView(MainActivity.this);
                        sv.addView(tv);
                        new AlertDialog.Builder(MainActivity.this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                                .setTitle("Crash logs")
                                .setView(sv)
                                .setPositiveButton("Close", null)
                                .setNeutralButton("Copy", new android.content.DialogInterface.OnClickListener() {
                                    @Override public void onClick(android.content.DialogInterface d, int w) {
                                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                                        if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("cyber-logs", s));
                                        toast("Logs copied");
                                    }
                                })
                                .show();
                    }
                });
            }
        }, "cyber-logs").start();
    }

    // ------------------------------------------------------------------ small helpers
    private void setStatus(String s, boolean error) {
        status.setText(s);
        status.setTextColor(error ? RED : GRAY);
        status.setVisibility(s == null || s.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void refreshFooter() {
        footer.setText("Engine: " + EngineProvider.get().name() + "  |  Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")"
                + "  |  64-bit: " + (Process.is64Bit() ? "yes" : "no"));
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button outlined(String label, int color) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(color);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setBackground(box(color, 0, 26));
        return b;
    }

    private GradientDrawable box(int stroke, int fill, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setStroke(dp(1), stroke);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private LinearLayout.LayoutParams lp(int l, int t, int r, int b) {
        return lpSize(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, l, t, r, b);
    }

    private LinearLayout.LayoutParams lpSize(int w, int hDp, int l, int t, int r, int b) {
        int h = hDp > 0 ? dp(hDp) : hDp;
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }
}
