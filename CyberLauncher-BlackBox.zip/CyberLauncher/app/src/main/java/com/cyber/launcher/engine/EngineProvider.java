package com.cyber.launcher.engine;

/** The engine adapter lives here (BlackBoxEngine; NoEngine is kept only as a build-without-engine fallback). Nothing else in the launcher depends on the engine. */
public final class EngineProvider {
    private static GuestEngine engine;

    private EngineProvider() { }

    public static synchronized GuestEngine get() {
        if (engine == null) engine = new BlackBoxEngine();
        return engine;
    }
}
