package com.cyber.launcher.core;

import android.content.Context;
import android.os.Environment;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;

/** Reads what libCybercrimson.so wrote (crimson_log.txt) plus this app's own logcat lines (guest runs under the same uid). */
public final class LogFiles {

    private LogFiles() { }

    public static String collect(Context c) {
        StringBuilder sb = new StringBuilder();

        List<File> cand = new ArrayList<File>();
        cand.add(new File(LibStore.sharedDir(), "crimson_log.txt"));
        cand.add(new File(Environment.getExternalStorageDirectory(), "HLLDev/crimson_log.txt"));
        File ext = c.getExternalFilesDir(null);
        if (ext != null) cand.add(new File(ext, "HLLDev/crimson_log.txt"));
        cand.add(new File(c.getFilesDir(), "crimson_log.txt"));
        // BlackBox redirects the guest's /sdcard to <ext files>/blackbox/storage/emulated/0/, so the menu's log lands there
        if (ext != null) {
            cand.add(new File(ext, "blackbox/storage/emulated/0/" + LibStore.FOLDER + "/crimson_log.txt"));
            cand.add(new File(ext, "blackbox/storage/emulated/0/HLLDev/crimson_log.txt"));
        }
        File best = null;
        for (int i = 0; i < cand.size(); i++) {
            File f = cand.get(i);
            if (f.isFile() && (best == null || f.lastModified() > best.lastModified())) best = f;
        }

        if (best != null) {
            sb.append("== ").append(best.getAbsolutePath()).append(" ==\n").append(tail(best, 24 * 1024)).append("\n");
        } else {
            sb.append("== crimson_log.txt not found in any known folder ==\n");
        }

        sb.append("\n== logcat (this app incl. BlackBox and guest processes: CyberGuest/CyberEngine/CrimsonGuard info, everything else warnings+) ==\n").append(logcat());
        return sb.toString();
    }

    private static String tail(File f, int max) {
        RandomAccessFile r = null;
        try {
            r = new RandomAccessFile(f, "r");
            long len = r.length();
            long start = Math.max(0L, len - max);
            r.seek(start);
            byte[] b = new byte[(int) (len - start)];
            r.readFully(b);
            return new String(b, "UTF-8");
        } catch (Exception e) {
            return "cannot read: " + e.getMessage();
        } finally {
            if (r != null) {
                try { r.close(); } catch (Exception ignored) { }
            }
        }
    }

    private static String logcat() {
        BufferedReader br = null;
        try {
            Process p = new ProcessBuilder("logcat", "-d", "-t", "800", "CyberGuest:I", "CyberEngine:I", "CrimsonGuard:I", "*:W")
                    .redirectErrorStream(true).start();
            StringBuilder sb = new StringBuilder();
            br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
            return sb.length() == 0 ? "(empty)\n" : sb.toString();
        } catch (Throwable t) {
            return "logcat unavailable: " + t.getMessage() + "\n";
        } finally {
            if (br != null) {
                try { br.close(); } catch (Exception ignored) { }
            }
        }
    }
}
