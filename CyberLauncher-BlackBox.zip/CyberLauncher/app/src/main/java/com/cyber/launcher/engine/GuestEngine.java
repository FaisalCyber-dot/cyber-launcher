package com.cyber.launcher.engine;

import android.app.Application;
import android.content.Context;

import java.util.List;

/**
 * The ONLY thing the launcher needs from a virtual-space engine.
 * Implement it once for the engine you build on (see ENGINE.md) and return it from EngineProvider.
 */
public interface GuestEngine {

    String name();

    /** LauncherApp.attachBaseContext - runs in the launcher process AND in every guest process. */
    void attachBaseContext(Context base);

    /** LauncherApp.onCreate - runs in the launcher process AND in every guest process. */
    void onCreate(Application app);

    /** True when the game is already cloned into the virtual space. */
    boolean isGuestInstalled(String packageName);

    /** Clone the game into the virtual space. hostApkPaths = base.apk + split apks of the real installed game. */
    void installGuest(String packageName, List<String> hostApkPaths) throws Exception;

    /** Kill the guest process so the next launch starts clean (the menu library must be loaded exactly once per process). */
    void stopGuest(String packageName);

    /** Start the game's launcher activity inside the virtual space. */
    void launchGuest(String packageName) throws Exception;
}
