package com.cyber.launcher.engine;

import android.app.Application;
import android.content.Context;
import android.util.Log;

import com.cyber.launcher.core.LibStore;
import com.cyber.launcher.guest.GuestBootstrap;

import java.io.File;
import java.util.List;

import top.niunaijun.blackbox.BlackBoxCore;
import top.niunaijun.blackbox.app.configuration.AppLifecycleCallback;
import top.niunaijun.blackbox.app.configuration.ClientConfiguration;
import top.niunaijun.blackbox.entity.pm.InstallResult;

/**
 * GuestEngine on top of BlackBox 2.1.0 (Bcore). Every BlackBoxCore call below exists in that source tree.
 *
 * Process model: the launcher, BlackBox's ":black" server and every guest process ":pN" all run this APK, so
 * attachBaseContext/onCreate run in all of them and BlackBoxCore works out which one it is.
 */
public final class BlackBoxEngine implements GuestEngine {

    private static final String TAG = "CyberEngine";
    private static final int USER = 0;   // BlackBox creates the user on first install

    private boolean callbackAdded;
    /** BlackBox init failure in this process. Kept instead of crashing the app, so the launcher can show it. */
    private volatile Throwable initError;

    @Override public String name() { return initError == null ? "BlackBox 2.1.0" : "BlackBox 2.1.0 (init FAILED)"; }

    private void ready() {
        Throwable t = initError;
        if (t != null) throw new IllegalStateException("BlackBox failed to initialise: " + t, t);
    }

    @Override
    public void attachBaseContext(final Context base) {
        try {
            BlackBoxCore.get().doAttachBaseContext(base, new ClientConfiguration() {
                @Override public String getHostPackageName() { return base.getPackageName(); }
            });
        } catch (Throwable t) {
            initError = t;
            Log.e(TAG, "doAttachBaseContext failed", t);
        }
    }

    @Override
    public void onCreate(Application app) {
        if (initError != null) return;
        try {
            BlackBoxCore core = BlackBoxCore.get();
            core.doCreate();
            // Only inside a guest process: BlackBox calls this right after the GAME's Application.onCreate,
            // with the game's Application object (BActivityThread.handleBindApplication).
            if (core.isBlackProcess() && !callbackAdded) {
                callbackAdded = true;
                core.addAppLifecycleCallback(new AppLifecycleCallback() {
                    @Override
                    public void afterApplicationOnCreate(String packageName, String processName, Application application, int userId) {
                        Log.i("CyberGuest", "game application ready: " + packageName + " in " + processName);
                        GuestBootstrap.install(application);
                    }
                });
            }
        } catch (Throwable t) {
            initError = t;
            Log.e(TAG, "doCreate failed", t);
        }
    }

    @Override
    public boolean isGuestInstalled(String packageName) {
        ready();
        return BlackBoxCore.get().isInstalled(packageName, USER);
    }

    /**
     * BlackBox installs ONE apk. Two sources are supported:
     *  1. CyberLauncher/<package>.apk (a universal apk you put there; needed for split installs and for games
     *     that are not installed on the phone),
     *  2. the real install, when it is a single base.apk (BlackBox then runs it from where it is).
     * A split install without (1) is refused: BlackBox 2.1.0 would "install" the base only and the game would
     * start without its native libraries.
     */
    @Override
    public void installGuest(String packageName, List<String> hostApkPaths) throws Exception {
        ready();
        File universal = LibStore.universalApk(packageName);
        InstallResult r;
        if (universal.isFile()) {
            Log.i(TAG, "installing from " + universal);
            r = BlackBoxCore.get().installPackageAsUser(universal, USER);
        } else if (hostApkPaths != null && hostApkPaths.size() == 1) {
            Log.i(TAG, "installing the real copy of " + packageName);
            r = BlackBoxCore.get().installPackageAsUser(packageName, USER);
        } else {
            int n = hostApkPaths == null ? 0 : hostApkPaths.size();
            throw new IllegalStateException(n > 1
                    ? packageName + " is installed as " + n + " split APKs and BlackBox installs a single APK. Put a universal "
                      + packageName + ".apk into " + LibStore.sharedDir().getAbsolutePath() + " and launch again."
                    : "Nothing to install for " + packageName + ". Put " + packageName + ".apk into " + LibStore.sharedDir().getAbsolutePath());
        }
        // BlackBox swallows install exceptions and still returns success=true, so ask it again
        if (r == null || !r.success || !BlackBoxCore.get().isInstalled(packageName, USER)) {
            String why = r != null && r.msg != null ? r.msg : "see CRASH LOGS (BPackageManagerService / System.err)";
            throw new IllegalStateException("BlackBox could not install " + packageName + ": " + why);
        }
    }

    @Override
    public void stopGuest(String packageName) {
        if (initError != null) return;
        try {
            if (BlackBoxCore.get().isInstalled(packageName, USER)) BlackBoxCore.get().stopPackage(packageName, USER);
        } catch (Throwable t) {
            Log.w(TAG, "stopPackage failed", t);
        }
    }

    @Override
    public void launchGuest(String packageName) throws Exception {
        ready();
        if (!BlackBoxCore.get().launchApk(packageName, USER)) {
            throw new IllegalStateException("BlackBox found no launcher activity for " + packageName + " (is it installed in the virtual space?)");
        }
    }
}
