package com.cyber.launcher.guest;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.Log;
import android.widget.Toast;

import com.crimson.guard.CrimsonMenu;
import com.crimson.guard.Native;
import com.cyber.launcher.LauncherApp;
import com.cyber.launcher.core.LibStore;
import com.mycompany.application.GLES3JNIView;

import java.lang.ref.WeakReference;

/**
 * Runs INSIDE the game process. The virtual engine calls install() once, right after the game's own Application
 * was created (see ENGINE.md). Everything else is driven by the game's activity lifecycle.
 *
 * Load order follows libCybercrimson.so:
 *   1. System.load()  -> constructor LibMain() installs the crash handlers and starts the hack thread,
 *                        JNI_OnLoad() stores the JavaVM and returns JNI_VERSION_1_6 (no FindClass there).
 *   2. a GL surface is created -> init() runs on the GL thread (it needs a current GLES3 context)
 *   3. resize() / step() / touch run on the GL thread.
 */
public final class GuestBootstrap {

    /** true  = com.mycompany.application.GLES3JNIView contract: X minimizes to the logo, menu keyboard only.
     *  false = com.crimson.guard.Native contract (CrimsonMenu): X closes the menu, system keyboard callbacks. */
    public static final boolean USE_HOSTED_CONTRACT = true;

    /** Ad / sign-in activities of the game get no menu. */
    private static final String[] SKIP_PREFIXES = {
            "com.google.android.gms", "com.google.android.play", "com.google.firebase", "com.unity3d.ads",
            "com.applovin", "com.ironsource", "com.facebook", "com.vungle", "com.chartboost"
    };

    private static final String TAG = "CyberGuest";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static boolean installed;
    private static boolean loadTried, loadOk;
    private static WeakReference<Activity> menuHost;

    private GuestBootstrap() { }

    /** Call in the guest process after the game's Application.onCreate. guestApp = the game's Application object. */
    public static synchronized void install(Application guestApp) {
        if (installed || guestApp == null) return;
        if (!Process.is64Bit()) { Log.e(TAG, "32-bit process: this launcher is 64-bit only, nothing injected"); return; }
        installed = true;
        guestApp.registerActivityLifecycleCallbacks(new Application.ActivityLifecycleCallbacks() {
            @Override public void onActivityCreated(Activity a, Bundle b) { created(a); }
            @Override public void onActivityStarted(Activity a) { }
            @Override public void onActivityResumed(Activity a) { resumed(a); }
            @Override public void onActivityPaused(Activity a) { paused(a); }
            @Override public void onActivityStopped(Activity a) { }
            @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
            @Override public void onActivityDestroyed(Activity a) { destroyed(a); }
        });
        Log.i(TAG, "bootstrap installed, process=" + Process.myPid());
    }

    private static boolean isSkipped(Activity a) {
        String n = a.getClass().getName();
        for (String p : SKIP_PREFIXES) if (n.startsWith(p)) return true;
        return false;
    }

    private static void created(final Activity a) {
        if (isSkipped(a)) return;
        final String lib = LibStore.readActive(LauncherApp.hostFilesDir());
        if (lib == null) return;                                   // "Inject menu" was off for this launch
        Activity cur = menuHost == null ? null : menuHost.get();
        if (cur != null && !cur.isFinishing() && !cur.isDestroyed()) return;   // the menu already lives in a game activity
        menuHost = new WeakReference<Activity>(a);
        // after the game finished its own onCreate/setContentView, otherwise setContentView would wipe the menu view
        MAIN.post(new Runnable() { @Override public void run() { attach(a, lib); } });
    }

    private static void attach(Activity a, String lib) {
        try {
            if (a.isFinishing() || a.isDestroyed()) return;
            if (!loadTried) {
                loadTried = true;
                if (USE_HOSTED_CONTRACT) GLES3JNIView.loadLib(lib); else Native.load(lib);
                loadOk = true;
                Log.i(TAG, "loaded " + lib);
            }
            if (!loadOk) return;
            if (USE_HOSTED_CONTRACT) GLES3JNIView.show(a); else CrimsonMenu.show(a);
            Log.i(TAG, "menu attached to " + a.getClass().getName());
        } catch (Throwable t) {
            Log.e(TAG, "menu attach failed", t);
            try { Toast.makeText(a, "Menu failed: " + t.getClass().getSimpleName() + " - " + t.getMessage(), Toast.LENGTH_LONG).show(); } catch (Throwable ignored) { }
        }
    }

    private static boolean isHost(Activity a) {
        Activity h = menuHost == null ? null : menuHost.get();
        return h == a;
    }

    private static void resumed(Activity a) {
        if (!isHost(a)) return;
        if (USE_HOSTED_CONTRACT) GLES3JNIView.resume(a); else CrimsonMenu.onResume();
    }

    private static void paused(Activity a) {
        if (!isHost(a)) return;
        if (USE_HOSTED_CONTRACT) GLES3JNIView.pause(a); else CrimsonMenu.onPause();
    }

    private static void destroyed(Activity a) {
        if (!isHost(a)) return;
        if (USE_HOSTED_CONTRACT) GLES3JNIView.hide(); else CrimsonMenu.hide();
        menuHost = null;
    }
}
