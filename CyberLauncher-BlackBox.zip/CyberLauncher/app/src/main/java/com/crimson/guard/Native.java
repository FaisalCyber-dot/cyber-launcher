package com.crimson.guard;

/** JNI bridge to libcrimson.so (src/main/jni/main.cpp). */
public class Native {

    public interface Callback {
        void onClose();                                   // X button pressed inside ImGui
        void onKeyboard(boolean show);                    // ImGui wants / no longer wants text input
        void onHitRect(int l, int t, int r, int b);       // area the menu covers (touches outside pass through)
    }

    public static volatile Callback callback;

    /**
     * The launcher loads the menu library from this class on purpose: System.load() binds the JNI natives
     * to the class loader of the CALLER, so the caller has to be the same loader that owns this class.
     */
    public static void load(String absolutePath) {
        System.load(absolutePath);
    }

    // All of these must run on the GL thread (ImGuiView uses queueEvent for you)
    public static native void init(float dp, int sdk, byte[] faFont);
    public static native void resize(int w, int h);
    public static native void draw();
    public static native void touch(int action, float x, float y);
    public static native void text(String s);
    public static native void key(int androidKeyCode, boolean down);
    public static native void clearFocus();
    public static native void setKeyboardTop(int px);     // top edge of the on-screen keyboard (view pixels), 0 = unknown

    // Called from native code (render thread)
    static void nOnClose() {
        Callback c = callback;
        if (c != null) c.onClose();
    }

    static void nOnKeyboard(boolean show) {
        Callback c = callback;
        if (c != null) c.onKeyboard(show);
    }

    static void nOnHitRect(int l, int t, int r, int b) {
        Callback c = callback;
        if (c != null) c.onHitRect(l, t, r, b);
    }
}
