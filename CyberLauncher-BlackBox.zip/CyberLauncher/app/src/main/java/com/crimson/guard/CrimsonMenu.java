package com.crimson.guard;

import android.app.Activity;
import android.os.Build;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;

/**
 * Puts the ImGui menu INSIDE an Activity's own window - no "Display over other apps" permission,
 * no service. Touches that do not hit the menu pass straight through to the app / game underneath.
 *
 *   CrimsonMenu.show(activity);      // add the menu on top of the activity's content
 *   CrimsonMenu.hide();              // remove it (X button does this too)
 *   CrimsonMenu.onPause() / onResume()   // forward from the activity lifecycle
 */
public final class CrimsonMenu implements Native.Callback {

    private static CrimsonMenu inst;
    private static Runnable closeListener;

    private final Activity activity;
    private final ImGuiView view;
    private final int oldSoftInput;

    private CrimsonMenu(Activity a) {
        activity = a;
        float dp = a.getResources().getDisplayMetrics().density;
        view = new ImGuiView(a, dp);
        oldSoftInput = a.getWindow().getAttributes().softInputMode;
    }

    // ------------------------------------------------------------------ public API
    public static synchronized void show(Activity a) {
        if (inst != null) {
            if (inst.activity == a) return;
            hide();
        }
        final CrimsonMenu m = new CrimsonMenu(a);
        inst = m;
        // the keyboard must not resize / pan the host window (the menu slides itself above it)
        a.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING);
        m.view.setCloseKeyboardListener(new Runnable() {
            @Override
            public void run() {
                m.setKeyboard(false);
            }
        });
        Native.callback = m;
        a.addContentView(m.view, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    public static synchronized void hide() {
        CrimsonMenu m = inst;
        if (m == null) return;
        inst = null;
        Native.callback = null;
        m.setKeyboard(false);
        if (m.view.getParent() instanceof ViewGroup) ((ViewGroup) m.view.getParent()).removeView(m.view);
        m.activity.getWindow().setSoftInputMode(m.oldSoftInput);
        Runnable l = closeListener;
        if (l != null) l.run();
    }

    public static boolean isShown() {
        return inst != null;
    }

    /** Called after the menu was closed (X button / hide()). Runs on the UI thread. */
    public static void setOnCloseListener(Runnable r) {
        closeListener = r;
    }

    public static void onPause() {
        if (inst != null) inst.view.onPause();
    }

    public static void onResume() {
        if (inst != null) inst.view.onResume();
    }

    // ------------------------------------------------------------------ Native.Callback (GL thread)
    private void setKeyboard(final boolean show) {
        view.setKeyboard(show);
    }

    @Override
    public void onClose() {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (inst == CrimsonMenu.this) hide();
            }
        });
    }

    @Override
    public void onKeyboard(final boolean show) {
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (inst == CrimsonMenu.this) view.setKeyboard(show);
            }
        });
    }

    @Override
    public void onHitRect(int l, int t, int r, int b) {
        view.setHitRect(l, t, r, b);
    }
}
