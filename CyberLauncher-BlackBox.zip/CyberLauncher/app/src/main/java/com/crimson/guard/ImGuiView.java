package com.crimson.guard;

import android.content.Context;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.opengl.GLSurfaceView;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.WindowInsets;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Full-window transparent GL surface that renders the ImGui menu.
 * - The menu (and the minimized logo) are drawn and dragged by ImGui itself.
 * - Native reports the rectangle the menu covers; a touch that starts OUTSIDE it is not consumed,
 *   so it reaches whatever sits below this view (the game / the app UI). No overlay permission needed.
 * - Acts as a text editor only while ImGui::InputText is active, so the default Android keyboard
 *   types into ImGui.
 */
public class ImGuiView extends GLSurfaceView {

    private final float dp;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final InputMethodManager imm;

    // area covered by the menu (view pixels). Written on the GL thread, read on the UI thread.
    private volatile int hitL, hitT, hitR, hitB;
    private boolean capturing;

    private volatile boolean textMode;
    private Runnable closeKeyboardListener;

    public ImGuiView(Context ctx, float density) {
        super(ctx);
        dp = density;
        imm = (InputMethodManager) ctx.getSystemService(Context.INPUT_METHOD_SERVICE);

        setEGLContextClientVersion(3);
        setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        getHolder().setFormat(PixelFormat.TRANSLUCENT);
        setZOrderOnTop(true);
        setRenderer(new MenuRenderer());
        setRenderMode(RENDERMODE_CONTINUOUSLY);
    }

    public void setCloseKeyboardListener(Runnable r) { closeKeyboardListener = r; }

    void setHitRect(int l, int t, int r, int b) {
        hitL = l; hitT = t; hitR = r; hitB = b;
    }

    // ------------------------------------------------------------------ touch
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        final int a = e.getActionMasked();

        if (a == MotionEvent.ACTION_DOWN) {
            final float x = e.getX(), y = e.getY();
            capturing = x >= hitL && x <= hitR && y >= hitT && y <= hitB;
            if (!capturing) return false;          // not on the menu -> let the view underneath have it
        }
        if (!capturing) return false;
        if (a == MotionEvent.ACTION_POINTER_DOWN || a == MotionEvent.ACTION_POINTER_UP) return true;

        final float x = e.getX();
        final float y = e.getY();
        final int action = a;
        queueEvent(new Runnable() {
            @Override
            public void run() {
                Native.touch(action, x, y);
            }
        });
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) capturing = false;
        return true;
    }

    // --------------------------------------------------------------- keyboard
    /** Called on the UI thread when ImGui starts / stops wanting text input. */
    void setKeyboard(boolean show) {
        textMode = show;
        if (show) {
            setFocusable(true);
            setFocusableInTouchMode(true);
            requestFocus();
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (!textMode) return;
                    imm.restartInput(ImGuiView.this);
                    imm.showSoftInput(ImGuiView.this, InputMethodManager.SHOW_FORCED);
                    pollKeyboardTop();
                }
            }, 80);
        } else {
            try { imm.hideSoftInputFromWindow(getWindowToken(), 0); } catch (Exception ignored) {}
            clearFocus();
            setFocusable(false);
            queueEvent(new Runnable() {
                @Override
                public void run() {
                    Native.setKeyboardTop(0);
                }
            });
        }
    }

    /** Tells native where the keyboard starts so the menu can slide up above it. */
    private void pollKeyboardTop() {
        if (!textMode) return;
        final int top = keyboardTop();
        queueEvent(new Runnable() {
            @Override
            public void run() {
                Native.setKeyboardTop(top);
            }
        });
        ui.postDelayed(new Runnable() {
            @Override
            public void run() {
                pollKeyboardTop();
            }
        }, 150);
    }

    @SuppressWarnings("deprecation")
    private int keyboardTop() {
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        int kb = 0;
        if (Build.VERSION.SDK_INT >= 23) {
            WindowInsets wi = getRootWindowInsets();
            if (wi != null) kb = wi.getSystemWindowInsetBottom() - wi.getStableInsetBottom();
        }
        if (kb > 0) {
            DisplayMetrics dm = new DisplayMetrics();
            getDisplay().getRealMetrics(dm);
            return dm.heightPixels - kb - loc[1];
        }
        Rect r = new Rect();
        getWindowVisibleDisplayFrame(r);
        int visible = r.bottom - loc[1];
        return (visible > 0 && visible < getHeight()) ? visible : 0;
    }

    @Override
    public boolean onCheckIsTextEditor() {
        return textMode;
    }

    @Override
    public boolean onKeyPreIme(int keyCode, KeyEvent event) {
        if (textMode && keyCode == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
            queueEvent(new Runnable() {
                @Override
                public void run() {
                    Native.clearFocus();
                }
            });
            if (closeKeyboardListener != null) closeKeyboardListener.run();
            return true;
        }
        return super.onKeyPreIme(keyCode, event);
    }

    @Override
    public InputConnection onCreateInputConnection(EditorInfo out) {
        out.inputType = InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS;
        out.imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI
                | EditorInfo.IME_FLAG_NO_FULLSCREEN
                | EditorInfo.IME_ACTION_DONE;
        return new ImGuiInputConnection(this);
    }

    private void sendText(final String s) {
        queueEvent(new Runnable() {
            @Override
            public void run() {
                Native.text(s);
            }
        });
    }

    private void sendKey(final int code) {
        queueEvent(new Runnable() {
            @Override
            public void run() {
                Native.key(code, true);
                Native.key(code, false);
            }
        });
    }

    private class ImGuiInputConnection extends BaseInputConnection {
        private int composingLen = 0;

        ImGuiInputConnection(android.view.View v) {
            super(v, false);
        }

        private void eraseComposing() {
            for (int i = 0; i < composingLen; i++) sendKey(KeyEvent.KEYCODE_DEL);
            composingLen = 0;
        }

        @Override
        public boolean setComposingText(CharSequence t, int newCursor) {
            eraseComposing();
            String s = t.toString();
            if (s.length() > 0) sendText(s);
            composingLen = s.length();
            return true;
        }

        @Override
        public boolean commitText(CharSequence t, int newCursor) {
            eraseComposing();
            String s = t.toString();
            if (s.length() > 0) sendText(s);
            return true;
        }

        @Override
        public boolean finishComposingText() {
            composingLen = 0;
            return true;
        }

        @Override
        public boolean deleteSurroundingText(int before, int after) {
            composingLen = 0;
            for (int i = 0; i < before; i++) sendKey(KeyEvent.KEYCODE_DEL);
            for (int i = 0; i < after; i++) sendKey(KeyEvent.KEYCODE_FORWARD_DEL);
            return true;
        }

        @Override
        public boolean sendKeyEvent(KeyEvent ev) {
            if (ev.getAction() == KeyEvent.ACTION_DOWN) {
                int k = ev.getKeyCode();
                if (k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_DEL
                        || k == KeyEvent.KEYCODE_FORWARD_DEL || k == KeyEvent.KEYCODE_TAB
                        || (k >= KeyEvent.KEYCODE_DPAD_UP && k <= KeyEvent.KEYCODE_DPAD_RIGHT)) {
                    composingLen = 0;
                    sendKey(k);
                } else {
                    int u = ev.getUnicodeChar();
                    if (u > 0) sendText(new String(Character.toChars(u)));
                }
            }
            return true;
        }

        @Override
        public boolean performEditorAction(int actionCode) {
            composingLen = 0;
            sendKey(KeyEvent.KEYCODE_ENTER);
            return true;
        }
    }

    // --------------------------------------------------------------- renderer
    private class MenuRenderer implements GLSurfaceView.Renderer {
        @Override
        public void onSurfaceCreated(GL10 gl, EGLConfig config) {
            Native.init(dp, Build.VERSION.SDK_INT, readAsset("fa-solid-900.ttf"));
        }

        @Override
        public void onSurfaceChanged(GL10 gl, int w, int h) {
            Native.resize(w, h);
        }

        @Override
        public void onDrawFrame(GL10 gl) {
            Native.draw();
        }
    }

    private byte[] readAsset(String name) {
        try {
            InputStream in = getContext().getAssets().open(name);
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            in.close();
            return bo.toByteArray();
        } catch (Exception e) {
            return null; // icons just fall back to '?' if the font is missing
        }
    }
}
