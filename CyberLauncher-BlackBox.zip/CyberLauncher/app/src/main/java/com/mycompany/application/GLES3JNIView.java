package com.mycompany.application;

import android.app.Activity;
import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * Java side of the "hosted" contract of libCybercrimson.so (main.cpp, section "com.mycompany.application.GLES3JNIView").
 * The method names and signatures below must stay exactly as they are: they are the JNI symbol names the library exports.
 * In this mode the menu needs no Java callbacks: X minimizes to the logo and text goes through the menu's own keyboard.
 */
public class GLES3JNIView extends GLSurfaceView implements GLSurfaceView.Renderer {

    public static native void init();
    public static native void resize(int w, int h);
    public static native void step();
    public static native void imgui_Shutdown();
    public static native void MotionEventClick(boolean down, float x, float y);
    public static native String getWindowRect();   // "x|y|w|h" of the area the menu covers, "0|0|0|0" = nothing

    /** Loads the library from THIS class, so the natives above bind to this class's loader. */
    public static void loadLib(String absolutePath) {
        System.load(absolutePath);
    }

    // ------------------------------------------------------------------ host handling
    private static GLES3JNIView current;
    private static Activity host;

    public static synchronized void show(Activity a) {
        if (current != null && host == a && current.getParent() != null) return;
        hide();
        GLES3JNIView v = new GLES3JNIView(a);
        a.addContentView(v, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        current = v;
        host = a;
    }

    public static synchronized void hide() {
        GLES3JNIView v = current;
        current = null;
        host = null;
        if (v != null && v.getParent() instanceof ViewGroup) ((ViewGroup) v.getParent()).removeView(v);
    }

    public static synchronized void pause(Activity a) {
        if (current != null && host == a) current.onPause();
    }

    public static synchronized void resume(Activity a) {
        if (current != null && host == a) current.onResume();
    }

    public static synchronized Activity hostActivity() {
        return host;
    }

    // ------------------------------------------------------------------ view
    private boolean capturing;

    private GLES3JNIView(Activity a) {
        super(a);
        setEGLContextClientVersion(3);
        setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        getHolder().setFormat(PixelFormat.TRANSLUCENT);
        setZOrderOnTop(true);
        setRenderer(this);
        setRenderMode(RENDERMODE_CONTINUOUSLY);
    }

    @Override public void onSurfaceCreated(GL10 gl, EGLConfig config) { init(); }
    @Override public void onSurfaceChanged(GL10 gl, int w, int h) { resize(w, h); }
    @Override public void onDrawFrame(GL10 gl) { step(); }

    private boolean insideMenu(float x, float y) {
        try {
            String[] p = getWindowRect().split("\\|");
            if (p.length < 4) return false;
            float l = Float.parseFloat(p[0]), t = Float.parseFloat(p[1]);
            float w = Float.parseFloat(p[2]), h = Float.parseFloat(p[3]);
            return w > 0 && h > 0 && x >= l && x <= l + w && y >= t && y <= t + h;
        } catch (Throwable ignored) {
            return false;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        final int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            capturing = insideMenu(e.getX(), e.getY());
            if (!capturing) return false;             // not on the menu: the game underneath gets the touch
        }
        if (!capturing) return false;
        if (a == MotionEvent.ACTION_POINTER_DOWN || a == MotionEvent.ACTION_POINTER_UP) return true;

        final boolean down = a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_MOVE;   // old contract: true for DOWN+MOVE, false for UP
        final float x = e.getX(), y = e.getY();
        queueEvent(new Runnable() {
            @Override public void run() { MotionEventClick(down, x, y); }   // ImGui input is touched on the render thread only
        });
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) capturing = false;
        return true;
    }
}
