# How BlackBox is wired in

## Calls (all verified by reading the 2.1.0 source, none executed)
| GuestEngine | BlackBoxCore |
|---|---|
| `attachBaseContext` | `doAttachBaseContext(base, ClientConfiguration)` |
| `onCreate` | `doCreate()`; in a guest process also `addAppLifecycleCallback(...)` whose `afterApplicationOnCreate` calls `GuestBootstrap.install(gameApplication)` |
| `isGuestInstalled` | `isInstalled(pkg, 0)` |
| `installGuest` | `installPackageAsUser(File universalApk, 0)` or `installPackageAsUser(pkg, 0)`, then `isInstalled` again |
| `stopGuest` | `stopPackage(pkg, 0)` |
| `launchGuest` | `launchApk(pkg, 0)` |

`LauncherApp` runs in the launcher, in BlackBox's `:black` server process and in every guest `:pN` process; BlackBoxCore tells them apart itself.
If BlackBox fails to initialise, the error is kept and shown by LAUNCH and in the footer ("init FAILED") instead of crashing the app.

## Things the BlackBox source does that matter here
- **Android versions.** BlackBox 2.1.0 documents support for Android 5.0 to 12. `BuildCompat` stops at Android 12 and the `android-mirror` package parser classes stop at Android 9. Nothing in the tree is written for Android 13/14, so a phone on 14 is outside what this engine claims to support. If it breaks, CRASH LOGS will name the failing hook.
- **Two install routes, different split handling (read from the source, not executed).**
  - `installPackageAsUser(File)` (the `CyberLauncher/<pkg>.apk` route) parses and copies ONE apk; `CopyExecutor` / `NativeUtils` take `lib/` from it only. Splits are not looked at, so that file has to be a real universal apk. Repacking splits into one APK is not done: it would destroy a v2/v3-only signature and the parser needs one.
  - `installPackageAsUser(String pkg)` (the real-copy route) parses the real base.apk but stores the phone's own `ApplicationInfo` (`FLAG_SYSTEM`: `aPackage.applicationInfo = ...getPackageInfo(pkg).applicationInfo`). `PackageManagerCompat.generateApplicationInfo` copies it, so `splitSourceDirs` and `nativeLibraryDir` of the real install reach the guest's `LoadedApk.mApplicationInfo`, and the class loader gets base + splits plus `<apk>!/lib/<abi>` for each of them. `CopyExecutor` copies nothing on this route. That is how split games are run now. `BActivityThread.handleBindApplication` also builds the `LoadedApk` with `createPackageContext(<game package>)`, so the game must be installed on the phone on this route.
  - Consequence: the clone points at `/data/app/~~.../` paths that change when the game is updated. `GameCheck.Info.stamp` (path:size:mtime of every apk) is compared on each launch and a change triggers a new install.
- **`installPackageAsUser` returns `success=true` even after an internal exception** (it only prints the stack trace). The adapter therefore checks `isInstalled` afterwards.
- **The guest's `/sdcard` is redirected** (`IOCore.enableRedirect`) to `<ext files>/blackbox/storage/emulated/0/`. The menu's `crimson_log.txt` therefore lands there; `LogFiles` looks in that folder too. The staged menu `.so` lives in the launcher's private files dir, which is not redirected.
- BlackBox's main process writes its own logcat to `Download/com.cyber.launcher_logcat.txt` (`BlackBoxCore.startLogcat`), useful for the first runs.
- 16 KB page size (Android 15+ devices): the BlackBox native libraries here are built with AGP 4.0.1 and are not aligned for it.

## Android 14 crash in `enableIO` (patched in `JniHook.cpp`, not built, not run on a device)
Crash log, TECNO KL5, Android 14, guest `com.dvloper.granny`, both launch attempts identical:
`NativeCore: jni hook error. class: java/io/UnixFileSystem, method: canonicalize0` (ART: `Failed to register non-native method ... as native`), then `JNI DETECTED ERROR ... FindClass called with pending exception NoSuchMethodError` in `NativeCore.enableIO` -> SIGABRT in the guest process.
Two defects in `JniHook::HookJniFun`: (1) the `ArtMethod` access-flag probe said "native" for a method ART considers non-native on this ROM, so `RegisterNatives` was called and failed; (2) after that failure the pending `NoSuchMethodError` was not cleared, so the next hook's `FindClass` aborted.
The patch asks the runtime via `Member.getModifiers()` whether the method is native (skip the hook if not) and clears the pending exception when `RegisterNatives` fails. Effect: hooks that cannot be installed are skipped with an `skip hook` / `jni hook error` line in logcat instead of killing the process. Skipped hooks mean those file calls are not path-redirected; whether the game still runs without them is untested.
Checked: `clang++ -fsyntax-only` of `JniHook.cpp` against a desktop `jni.h` with stub Android headers (the original file passes the same check). Not checked: NDK build, device run.

## If the Android 14 phone does not work with 2.1.0
Search leads (not checked by me): the GitHub fork `ALEX5402/NewBlackbox` states Android 14+ support, and `BryanGIG/Android-Virtual-Inject` is an injector built on it. Only `engine/BlackBoxEngine.java` talks to the engine; a fork with the same `top.niunaijun.blackbox` API needs no other launcher change, a different API means rewriting that one file.
