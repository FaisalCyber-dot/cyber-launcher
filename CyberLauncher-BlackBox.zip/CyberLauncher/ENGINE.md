# How BlackBox is wired in

## Calls (all verified by reading the 2.1.0 source, none executed)
| GuestEngine | BlackBoxCore |
|---|---|
| `attachBaseContext` | `doAttachBaseContext(base, ClientConfiguration)` |
| `onCreate` | `doCreate()`; in a guest process also `addAppLifecycleCallback(...)` whose `afterApplicationOnCreate` calls `GuestBootstrap.install(gameApplication)` |
| `isGuestInstalled` | `isInstalled(pkg, 0)` |
| `installGuest` | `installPackageAsUser(File universalApk, 0)` or `installPackageAsUser(pkg, 0)`, then `isInstalled` again |
| `stopGuest` | `stopPackage(pkg, 0)` |
| `launchGuest` | `launchApk(pkg, 0)` |

`LauncherApp` runs in the launcher, in BlackBox's `:black` server process and in every guest `:pN` process; BlackBoxCore tells them apart itself.
If BlackBox fails to initialise, the error is kept and shown by LAUNCH and in the footer ("init FAILED") instead of crashing the app.

## Things the BlackBox source does that matter here
- **Android versions.** BlackBox 2.1.0 documents support for Android 5.0 to 12. `BuildCompat` stops at Android 12 and the `android-mirror` package parser classes stop at Android 9. Nothing in the tree is written for Android 13/14, so a phone on 14 is outside what this engine claims to support. If it breaks, CRASH LOGS will name the failing hook.
- **Install only reads one APK.** `CopyExecutor` / `NativeUtils` take `lib/` from the base APK only, so split installs are refused with a message unless `CyberLauncher/<pkg>.apk` exists. Repacking splits into one APK was not done: it would destroy a v2/v3-only signature and the parser needs one.
- **`installPackageAsUser` returns `success=true` even after an internal exception** (it only prints the stack trace). The adapter therefore checks `isInstalled` afterwards.
- **The guest's `/sdcard` is redirected** (`IOCore.enableRedirect`) to `<ext files>/blackbox/storage/emulated/0/`. The menu's `crimson_log.txt` therefore lands there; `LogFiles` looks in that folder too. The staged menu `.so` lives in the launcher's private files dir, which is not redirected.
- BlackBox's main process writes its own logcat to `Download/com.cyber.launcher_logcat.txt` (`BlackBoxCore.startLogcat`), useful for the first runs.
- 16 KB page size (Android 15+ devices): the BlackBox native libraries here are built with AGP 4.0.1 and are not aligned for it.

## If the Android 14 phone does not work with 2.1.0
Search leads (not checked by me): the GitHub fork `ALEX5402/NewBlackbox` states Android 14+ support, and `BryanGIG/Android-Virtual-Inject` is an injector built on it. Only `engine/BlackBoxEngine.java` talks to the engine; a fork with the same `top.niunaijun.blackbox` API needs no other launcher change, a different API means rewriting that one file.
