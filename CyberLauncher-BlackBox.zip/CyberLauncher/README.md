# Cyber Launcher (BlackBox 2.1.0 engine)

Virtual-space launcher that loads your `libCybercrimson.so` into a game (default `com.dvloper.granny`) without touching the game's APK.
The engine is BlackBox 2.1.0 (`Bcore`, `android-mirror`, from the GitHub source; Apache-2.0, see `LICENSE-BlackBox`). Two engine files are changed: `Bcore/.../fake/service/IPackageManagerProxy.java` (Android 13+ passes the PackageManager flags as long, the stock code cast them to int and crashed) and `Bcore/src/main/cpp/JniHook/JniHook.cpp` (on Android 14 the hook of `java.io.UnixFileSystem.canonicalize0` failed and aborted the guest process, see `ENGINE.md`).

## Use
1. Put `libCybercrimson.so` into `/storage/emulated/0/CyberLauncher/` (the app creates the folder after you allow storage access).
2. Open the app, type or PASTE the package name, pick the .so, keep "Inject menu" on, press LAUNCH.
3. First launch clones the game into the virtual space. Single-APK and split-APK installs (base + `split_config.*`) are both
   used straight from where Android installed them; if the game is updated, the next launch clones it again.
   If the game is not installed on the phone, put a universal `<package>.apk` (e.g. `com.dvloper.granny.apk`) into the same folder.
   A changed file is cloned again, and a universal file always wins over the installed copy.
4. If something fails, CRASH LOGS shows the menu's log plus this app's logcat (BlackBox and the guest processes included).

## Build
Toolchain is BlackBox's own, because its modules are written for it:

| Needed | Value (from the build files) |
|---|---|
| JDK | 8 or 11 (Gradle 6.5 does not run on JDK 17) |
| Gradle / AGP | wrapper 6.5 / 4.0.1 (already in the project) |
| SDK platforms | android-28 (Bcore) and android-30 |
| Build-tools | 28.0.2 (Bcore, pine) and 30.0.3 (app, black-hook, black-fake) |
| NDK + CMake | Bcore and pine-core build native code; AGP 4.0.1 picks its default NDK/CMake, install the version Gradle names if it complains |

    ./gradlew :app:assembleDebug

APK: `app/build/outputs/apk/debug/app-debug.apk`. No build was run by me, see the status in the chat.

## Layout
- `Bcore/`, `android-mirror/` BlackBox 2.1.0 (only `IPackageManagerProxy.java` changed, see above)
- `app/` the launcher
  - `engine/BlackBoxEngine.java` the only BlackBox-specific file of the launcher; `EngineProvider` returns it
  - `guest/GuestBootstrap.java` runs inside the game process (called from BlackBox's `afterApplicationOnCreate`)
  - `core/` CyberLauncher folder + ELF check + read-only staged copy (`LibStore`), game 64-bit check (`GameCheck`), log reader
  - `com/mycompany/application/GLES3JNIView.java` hosted contract, `com/crimson/guard/*` standalone contract classes
- `menu-changes/logs.patch` unchanged, still applies to your menu project

See `ENGINE.md` for how the engine is wired and what is known to be risky.
